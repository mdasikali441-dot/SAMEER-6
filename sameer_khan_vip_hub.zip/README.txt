SAMEER KHAN [2014] - VIP Hub

ব্যবহার:
1. ZIP ফাইলটি Extract/Unzip করুন।
2. index.html ফাইলটি ব্রাউজারে খুললে ওয়েবপেজটি দেখা যাবে।
3. অনলাইনে প্রকাশ করতে index.html ফাইলটি GitHub Pages, Netlify বা অন্য হোস্টিং সাইটে আপলোড করুন।

নোট: ছবি, Google Fonts এবং Font Awesome দেখাতে ইন্টারনেট প্রয়োজন।
